﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace ClaimDataManager
{
    public class Claim
    {
        public int ClaimId { get; set; }

        public string LecturerName { get; set; } = string.Empty;

        public string ModuleCode { get; set; } = string.Empty;

        public int HoursWorked { get; set; }

        public decimal HourlyRate { get; set; }

        public string ClaimMonth { get; set; } = string.Empty;

        public string Status { get; set; } = "Draft";

        // Calculates the total claim amount.
        // This property is calculated and is not stored in the database.
        [NotMapped]
        public decimal TotalAmount
        {
            get { return HoursWorked * HourlyRate; }
        }
    }
}
