﻿
using Microsoft.EntityFrameworkCore;

namespace ClaimDataManager
{
    public class ClaimContext : DbContext
    {
        private readonly string _databasePath;

        public ClaimContext(string databasePath)
        {
            _databasePath = databasePath;
        }

        // Represents the Claims table in SQLite.
        public DbSet<Claim> Claims { get; set; }

        protected override void OnConfiguring(
            DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(
                $"Data Source={_databasePath}");
        }
    }
}
