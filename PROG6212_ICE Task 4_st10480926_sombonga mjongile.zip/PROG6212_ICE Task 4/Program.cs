﻿
using System;
using System.IO;
using System.Linq;
using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;

namespace ClaimDataManager
{
    internal class Program
    {
        private static string databasePath = "";
        private static string projectDirectory = "";

        static void Main(string[] args)
        {
            try
            {
                // Find the project folder so files are stored
                // in the correct location.
                projectDirectory = FindProjectDirectory();

                databasePath = Path.Combine(
                    projectDirectory, "claims.db");

                // Create the database and Claims table.
                using (var context = new ClaimContext(databasePath))
                {
                    context.Database.EnsureCreated();

                    // Insert sample records only if the table is empty.
                    SeedDatabase(context);
                }

                Console.WriteLine("======================================");
                Console.WriteLine("   CONTRACT CLAIM DATA MANAGER");
                Console.WriteLine("======================================");
                Console.WriteLine("Database connected successfully!");

                RunMenu();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An unexpected error occurred:");
                Console.WriteLine(ex.Message);
            }
        }

        // Finds the project directory when running from Visual Studio.
        private static string FindProjectDirectory()
        {
            DirectoryInfo? directory =
                new DirectoryInfo(AppContext.BaseDirectory);

            while (directory != null)
            {
                if (File.Exists(Path.Combine(
                    directory.FullName, "ClaimDataManager.csproj")))
                {
                    return directory.FullName;
                }

                directory = directory.Parent;
            }

            return Directory.GetCurrentDirectory();
        }

        // Adds two sample claims only when no records exist.
        private static void SeedDatabase(ClaimContext context)
        {
            if (!context.Claims.Any())
            {
                var sampleClaims = new[]
                {
                    new Claim
                    {
                        LecturerName = "Nomsa Mthembu",
                        ModuleCode = "PROG6212",
                        HoursWorked = 10,
                        HourlyRate = 350,
                        ClaimMonth = "November 2026",
                        Status = "Submitted"
                    },

                    new Claim
                    {
                        LecturerName = "Sibusiso Khumalo",
                        ModuleCode = "DBAS6211",
                        HoursWorked = 8,
                        HourlyRate = 300,
                        ClaimMonth = "November 2026",
                        Status = "Draft"
                    }
                };

                context.Claims.AddRange(sampleClaims);
                context.SaveChanges();

                Console.WriteLine("Two sample claims added.");
            }
            else
            {
                Console.WriteLine("Existing claim records found.");
                Console.WriteLine("Sample records were not added again.");
            }
        }

        // Displays the main application menu.
        private static void RunMenu()
        {
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n======================================");
                Console.WriteLine("              MAIN MENU");
                Console.WriteLine("======================================");
                Console.WriteLine("1. Add a new claim");
                Console.WriteLine("2. View all claims");
                Console.WriteLine("3. Update claim status");
                Console.WriteLine("4. Delete a claim");
                Console.WriteLine("5. Export claims to text file");
                Console.WriteLine("6. Display ADO.NET record count");
                Console.WriteLine("7. Exit");
                Console.WriteLine("======================================");

                Console.Write("Select an option: ");

                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddClaim();
                        break;

                    case "2":
                        ViewClaims();
                        break;

                    case "3":
                        UpdateClaim();
                        break;

                    case "4":
                        DeleteClaim();
                        break;

                    case "5":
                        ExportClaims();
                        break;

                    case "6":
                        DisplayRecordCount();
                        break;

                    case "7":
                        running = false;
                        Console.WriteLine(
                            "Thank you for using Contract Claim Data Manager.");
                        break;

                    default:
                        Console.WriteLine(
                            "Invalid option. Please select 1 to 7.");
                        break;
                }
            }
        }

        // Adds a new lecturer claim.
        private static void AddClaim()
        {
            try
            {
                Console.WriteLine("\n--- ADD NEW CLAIM ---");

                string name = ReadRequiredText("Lecturer name: ");
                string module = ReadRequiredText("Module code: ");

                int hours = ReadHours();

                decimal rate = ReadHourlyRate();

                string month = ReadRequiredText("Claim month: ");

                using (var context = new ClaimContext(databasePath))
                {
                    Claim newClaim = new Claim
                    {
                        LecturerName = name,
                        ModuleCode = module,
                        HoursWorked = hours,
                        HourlyRate = rate,
                        ClaimMonth = month,
                        Status = "Draft"
                    };

                    context.Claims.Add(newClaim);
                    context.SaveChanges();

                    Console.WriteLine("\nClaim added successfully!");
                    Console.WriteLine("Claim ID: " + newClaim.ClaimId);
                    Console.WriteLine("Status: Draft");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error adding claim: " + ex.Message);
            }
        }

        // Displays all saved claims.
        private static void ViewClaims()
        {
            try
            {
                using (var context = new ClaimContext(databasePath))
                {
                    var claims = context.Claims
                        .OrderBy(c => c.ClaimId)
                        .ToList();

                    Console.WriteLine("\n--- ALL CLAIM RECORDS ---");

                    if (claims.Count == 0)
                    {
                        Console.WriteLine("No claims found.");
                        return;
                    }

                    foreach (var claim in claims)
                    {
                        DisplayClaim(claim);
                    }

                    Console.WriteLine(
                        $"Total number of claims: {claims.Count}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error viewing claims: " + ex.Message);
            }
        }

        // Displays the details of an individual claim.
        private static void DisplayClaim(Claim claim)
        {
            Console.WriteLine("\n--------------------------------------");
            Console.WriteLine($"Claim ID: {claim.ClaimId}");
            Console.WriteLine($"Lecturer Name: {claim.LecturerName}");
            Console.WriteLine($"Module Code: {claim.ModuleCode}");
            Console.WriteLine($"Hours Worked: {claim.HoursWorked}");
            Console.WriteLine($"Hourly Rate: {claim.HourlyRate:C}");
            Console.WriteLine($"Claim Month: {claim.ClaimMonth}");
            Console.WriteLine($"Status: {claim.Status}");
            Console.WriteLine($"Total Amount: {claim.TotalAmount:C}");
            Console.WriteLine("--------------------------------------");
        }

        // Updates the status of an existing claim.
        private static void UpdateClaim()
        {
            try
            {
                Console.WriteLine("\n--- UPDATE CLAIM STATUS ---");

                int id = ReadPositiveInteger("Enter claim ID: ");

                using (var context = new ClaimContext(databasePath))
                {
                    var claim = context.Claims.Find(id);

                    if (claim == null)
                    {
                        Console.WriteLine("Claim not found.");
                        return;
                    }

                    Console.WriteLine(
                        $"Current status: {claim.Status}");

                    string newStatus = ReadRequiredText(
                        "Enter new status: ");

                    claim.Status = newStatus;

                    context.SaveChanges();

                    Console.WriteLine(
                        "Claim status updated successfully!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating claim: " + ex.Message);
            }
        }

        // Deletes a claim after confirmation.
        private static void DeleteClaim()
        {
            try
            {
                Console.WriteLine("\n--- DELETE CLAIM ---");

                int id = ReadPositiveInteger("Enter claim ID: ");

                using (var context = new ClaimContext(databasePath))
                {
                    var claim = context.Claims.Find(id);

                    if (claim == null)
                    {
                        Console.WriteLine("Claim not found.");
                        return;
                    }

                    DisplayClaim(claim);

                    Console.Write(
                        "Are you sure you want to delete this claim? (Y/N): ");

                    string? confirmation = Console.ReadLine();

                    if (confirmation?.Trim().Equals(
                        "Y", StringComparison.OrdinalIgnoreCase) == true)
                    {
                        context.Claims.Remove(claim);
                        context.SaveChanges();

                        Console.WriteLine(
                            "Claim deleted successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Deletion cancelled.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting claim: " + ex.Message);
            }
        }

        // Exports all claims to a text file.
        private static void ExportClaims()
        {
            try
            {
                string reportsDirectory = Path.Combine(
                    projectDirectory, "Reports");

                // Create Reports directory if it does not exist.
                Directory.CreateDirectory(reportsDirectory);

                string filePath = Path.Combine(
                    reportsDirectory, "claim_summary.txt");

                using (var context = new ClaimContext(databasePath))
                {
                    var claims = context.Claims
                        .OrderBy(c => c.ClaimId)
                        .ToList();

                    // Write the claim information into the report.
                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        writer.WriteLine("CONTRACT CLAIM DATA MANAGER");
                        writer.WriteLine("LECTURER CLAIM SUMMARY");
                        writer.WriteLine("======================================");

                        foreach (var claim in claims)
                        {
                            writer.WriteLine($"Claim ID: {claim.ClaimId}");
                            writer.WriteLine(
                                $"Lecturer: {claim.LecturerName}");
                            writer.WriteLine(
                                $"Module: {claim.ModuleCode}");
                            writer.WriteLine(
                                $"Hours Worked: {claim.HoursWorked}");
                            writer.WriteLine(
                                $"Hourly Rate: {claim.HourlyRate:C}");
                            writer.WriteLine(
                                $"Claim Month: {claim.ClaimMonth}");
                            writer.WriteLine(
                                $"Status: {claim.Status}");
                            writer.WriteLine(
                                $"Total Amount: {claim.TotalAmount:C}");
                            writer.WriteLine("--------------------------------------");
                        }

                        writer.WriteLine(
                            $"Total Claims: {claims.Count}");
                    }
                }

                Console.WriteLine("\nReport exported successfully!");
                Console.WriteLine("File location: " + filePath);

                // Read the completed file and display its contents.
                Console.WriteLine("\n--- EXPORTED REPORT ---");

                string reportContents = File.ReadAllText(filePath);

                Console.WriteLine(reportContents);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error exporting report: " + ex.Message);
            }
        }

        // Executes a direct ADO.NET query against SQLite.
        private static void DisplayRecordCount()
        {
            try
            {
                string connectionString =
                    $"Data Source={databasePath}";

                using (SqliteConnection connection =
                    new SqliteConnection(connectionString))
                {
                    connection.Open();

                    string query =
                        "SELECT COUNT(*) FROM Claims;";

                    using (SqliteCommand command =
                        new SqliteCommand(query, connection))
                    {
                        object? result = command.ExecuteScalar();

                        long recordCount = Convert.ToInt64(result);

                        Console.WriteLine(
                            "\n--- DIRECT ADO.NET QUERY ---");

                        Console.WriteLine(
                            "Total claim records in database: "
                            + recordCount);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    "Error executing ADO.NET query: " + ex.Message);
            }
        }

        // Validates that required text fields are not empty.
        private static string ReadRequiredText(string message)
        {
            while (true)
            {
                Console.Write(message);

                string? value = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(value))
                {
                    return value.Trim();
                }

                Console.WriteLine(
                    "This field cannot be empty. Please try again.");
            }
        }

        // Validates hours between 1 and 160.
        private static int ReadHours()
        {
            while (true)
            {
                Console.Write("Hours worked (1-160): ");

                if (int.TryParse(Console.ReadLine(), out int hours)
                    && hours >= 1 && hours <= 160)
                {
                    return hours;
                }

                Console.WriteLine(
                    "Invalid hours. Enter a value between 1 and 160.");
            }
        }

        // Validates that the hourly rate is greater than zero.
        private static decimal ReadHourlyRate()
        {
            while (true)
            {
                Console.Write("Hourly rate: ");

                if (decimal.TryParse(
                    Console.ReadLine(),
                    NumberStyles.Number,
                    CultureInfo.CurrentCulture,
                    out decimal rate)
                    && rate > 0)
                {
                    return rate;
                }

                Console.WriteLine(
                    "Invalid rate. The hourly rate must be greater than zero.");
            }
        }

        // Validates positive integer IDs.
        private static int ReadPositiveInteger(string message)
        {
            while (true)
            {
                Console.Write(message);

                if (int.TryParse(Console.ReadLine(), out int value)
                    && value > 0)
                {
                    return value;
                }

                Console.WriteLine(
                    "Please enter a valid positive number.");
            }
        }
    }
}
